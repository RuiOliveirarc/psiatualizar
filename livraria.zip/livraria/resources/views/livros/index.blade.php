<ul>
	
@foreach($livros as $livro)
	<li><a href="{{route('livros.edit',['id'=>$livro->id_livro])}}">Editar</a>
		<a href="{{route('livros.show',['id'=>$livro->id_livro])}}">
			{{$livro->titulo}}
		</a>
	</li>
@endforeach
</ul>
{{$livros->render()}}