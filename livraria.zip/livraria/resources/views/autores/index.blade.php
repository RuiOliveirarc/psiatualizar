<ul>
@foreach($autores as $autor)
	<li><a href="{{route('autores.edit',['id'=>$autor->id_autor])}}">Editar</a>
		<a href="{{route('autores.show',['id'=>$autor->id_autor])}}">
			{{$autor->nome}}
		</a>
	</li>
@endforeach
</ul>
{{$autores->render()}}