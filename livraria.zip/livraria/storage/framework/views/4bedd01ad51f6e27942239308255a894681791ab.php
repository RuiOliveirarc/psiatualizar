<form action="<?php echo e(route('editoras.update', ['id'=>$editora->id_editora])); ?>" method="post">

	<?php echo csrf_field(); ?>
	<?php echo method_field('patch'); ?>

	Nome: <input type="text" name="nome" value="<?php echo e($editora->nome); ?>">
	<br>
		<?php if($errors->has('nome')): ?>
			Deverá indicar um nome correto(Tem letras)<br>
		<?php endif; ?>

	Morada: <input type="text" name="morada" value="<?php echo e($editora->morada); ?>">
	<br>
		<?php if($errors->has('morada')): ?>
			Deverá indicar uma morada correta(letras)<br>
		<?php endif; ?>

	Observações: <textarea name="observacoes"><?php echo e($editora->observacoes); ?></textarea>
	<br>

		<?php if($errors->has('observacoes')): ?>
			Deverá indicar observacoes correto<br>
		<?php endif; ?>
	
	<input type="submit" name="enviar">
</form><?php /**PATH C:\Users\Professor\Downloads\psicreate-main\livraria\resources\views/editoras/edit.blade.php ENDPATH**/ ?>