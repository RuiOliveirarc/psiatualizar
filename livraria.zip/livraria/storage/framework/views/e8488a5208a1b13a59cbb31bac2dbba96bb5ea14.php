ID:<?php echo e($livro->id_livro); ?><br>
Título:<?php echo e($livro->titulo); ?><br>
Idioma:<?php echo e($livro->idioma); ?><br>


<?php /**PATH C:\Users\Professor\Downloads\psicreate-main\livraria\resources\views/livros/show.blade.php ENDPATH**/ ?>