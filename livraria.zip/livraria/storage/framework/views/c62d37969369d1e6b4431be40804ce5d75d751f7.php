<form action="<?php echo e(route('livros.store')); ?>" method="post">

	<?php echo csrf_field(); ?>

	Título: <input type="text" name="titulo">
	<br>
	<?php if($errors->has('titulo')): ?>
		Deverá indicar um titulo correto(Tem letras)<br>
	<?php endif; ?>

	Idioma: <input type="text" name="idioma">
	<br>
	<?php if($errors->has('idioma')): ?>
		Deverá indicar um idioma correto(letras)<br>
	<?php endif; ?>

	Total páginas: <input type="text" name="total_paginas">
	<br>
	<?php if($errors->has('total_paginas')): ?>
		Deverá indicar um titulo correto(Numero sem letras)<br>
	<?php endif; ?>

	Data Edição: <input type="date" name="data_edicao">
	<br>
	<?php if($errors->has('data_edicao')): ?>
		Deverá indicar uma data correta<br>
	<?php endif; ?>

	ISBN: <input type="text" name="isbn" >
	<br>

	<?php if($errors->has('isbn')): ?>
		Deverá indicar um isbn correto(13 carateres)<br>
	<?php endif; ?>
	

	Observações: <textarea name="observacoes"></textarea>
	<br>

	<?php if($errors->has('observacoes')): ?>
		Deverá indicar observacoes correto<br>
	<?php endif; ?>

	Imagem capa: <input type="text" name="imagem_capa">
	<br>

	<?php if($errors->has('imagem_capa')): ?>
		Deverá indicar uma imagem correta<br>
	<?php endif; ?>

	Genero: <input type="text" name="id_genero">
	<br>

	<?php if($errors->has('id_genero')): ?>
		Deverá indicar um id do genero correto<br>
	<?php endif; ?>

	Autores: <input type="text" name="id_autor">
	<br>

	<?php if($errors->has('id_autor')): ?>
		Deverá indicar um id do autor correto<br>
	<?php endif; ?>

	Sinópse: <textarea name="sinopse"></textarea>
	<br>

	<?php if($errors->has('sinopse')): ?>
		Deverá indicar ua sinopse correta<br>
	<?php endif; ?>

	<input type="submit" name="enviar">
</form><?php /**PATH D:\psiat6-main\livraria\resources\views/livros/create.blade.php ENDPATH**/ ?>