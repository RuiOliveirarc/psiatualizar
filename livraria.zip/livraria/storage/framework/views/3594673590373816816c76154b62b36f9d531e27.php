ID:<?php echo e($autor->id_autor); ?><br>
Nome:<?php echo e($autor->nome); ?><br>
Nacionalidade:<?php echo e($autor->nacionalidade); ?>



<h2>Livros:</h2>
<?php $__currentLoopData = $autor->livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<h4><?php echo e($livro->titulo); ?></h4>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\Professor\Downloads\psicreate-main\livraria\resources\views/autores/show.blade.php ENDPATH**/ ?>