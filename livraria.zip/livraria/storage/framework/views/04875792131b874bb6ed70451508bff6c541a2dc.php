<ul>
<?php $__currentLoopData = $generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li>
		<a href="<?php echo e(route('generos.show',['id'=>$genero->id_genero])); ?>">
			<?php echo e($genero->designacao); ?>

		</a>
	</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($generos->render()); ?><?php /**PATH C:\Users\Filipe\Desktop\psiat5-main\livraria\resources\views/generos/index.blade.php ENDPATH**/ ?>